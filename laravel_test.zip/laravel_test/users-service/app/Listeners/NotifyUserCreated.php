<?php
// app/Listeners/NotifyUserCreated.php

use App\Events\UserCreated;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Log;

class NotifyUserCreated implements ShouldQueue
{
    public function handle(UserCreated $event)
    {
        Log::info('User created: ' . $event->user);
    }
}
