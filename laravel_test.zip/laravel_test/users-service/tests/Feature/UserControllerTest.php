<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Support\Facades\Event;
use App\Events\UserCreated;
use Tests\TestCase;

class UserControllerTest extends TestCase
{
    use RefreshDatabase;

    public function test_user_can_be_created()
    {
        Event::fake();

        $data = [
            'firstName' => 'John',
            'lastName' => 'Doe',
            'email' => 'test@example.com',
        ];

        $response = $this->postJson('/users', $data);

        $response->dump(); // Output the response for debugging

        $response->assertStatus(201);
        $this->assertDatabaseHas('users', ['email' => 'test@example.com']);
        Event::assertDispatched(UserCreated::class);
    }

}
