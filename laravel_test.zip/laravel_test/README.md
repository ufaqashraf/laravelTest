# Laravel Microservices Project

This project contains two microservices built with Laravel that communicate via a message bus. One microservice is responsible for managing users, and the other microservice handles notifications.

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes.

### Prerequisites

Make sure you have Docker and Docker Compose installed on your local machine.

- [Docker](https://docs.docker.com/get-docker/)
- [Docker Compose](https://docs.docker.com/compose/install/)

### Installing

1. Clone the repository to your local machine:

   ```bash
   git clone https://github.com/yourusername/laravel-microservices.git
   ```

2. Navigate to the project directory:

   ```bash
   cd laravel-microservices
   ```

3. Run Docker Compose to build and start the services:

   ```bash
   docker-compose up --build
   ```

4. Once the containers are up and running, you can access the microservices:

   - Users Microservice: http://localhost:8000
   - Notifications Microservice: http://localhost:8001

### Usage

- Use the Users Microservice to create new users by sending a POST request to `/users` with JSON payload `{"email": "user@example.com", "firstName": "John", "lastName": "Doe"}`.
- The Users Microservice will emit a UserCreated event upon user creation, which will be consumed by the Notifications Microservice to log the new user data.

### Additional Configuration

- You can configure environment variables in the `.env` files located in each microservice directory (`users-service` and `notifications-service`).
- Adjust Docker Compose ports or add additional services as required by modifying the `docker-compose.yml` file.

### Running Tests

- Tests can be run within each microservice container using PHPUnit.

  ```bash
  docker-compose exec users-service ./vendor/bin/phpunit
  ```

  ```bash
  docker-compose exec notifications-service ./vendor/bin/phpunit
  ```

### Cleanup

To stop and remove the Docker containers, run:

```bash
docker-compose down
```
